import java.util.Scanner;

public class ex4 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        System.out.print("Informe a quantidade de pessoas: ");
        int quantidadePessoas = s.nextInt();
        
        System.out.print("Informe o tamanho da pizza (broto,pequena,media,grande): ");
        String tamanhoPizza = s.next().toLowerCase();
        
        int pizzas = 0;
        
        switch (tamanhoPizza) {
            case "broto":
                pizzas = (int) Math.ceil(quantidadePessoas / 1.0);
                break;
            case "pequena":
                pizzas = (int) Math.ceil(quantidadePessoas / 2.0);
                break;
            case "media":
                pizzas = (int) Math.ceil(quantidadePessoas / 3.0);
                break;
            case "grande":
                pizzas = (int) Math.ceil(quantidadePessoas / 4.0);
                break;
            default:
                System.out.println("Tamanho de pizza invalido.");
                s.close();
                return;
        }
        
        System.out.printf("Vc precisara de %d pizzas.%n", pizzas);
        
        s.close();
    }
}