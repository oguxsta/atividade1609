import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        System.out.print("Informe sua altura em metros: ");
        double altura = s.nextDouble();
        
        System.out.print("Informe seu peso em kg: ");
        double peso = s.nextDouble();
        
        System.out.print("Informe o sexo (homem/mulher): ");
        String sexo = s.next().toLowerCase();
        
        double pesoIdeal = 0;
        
        if (sexo.equals("homem")) {
            pesoIdeal = (72.7 * altura) - 58;
        } else if (sexo.equals("mulher")) {
            pesoIdeal = (62.1 * altura) - 44.7;
        } else {
            System.out.println("Sexo inválido.");
            s.close();
            return;
        }
        
        if (peso < pesoIdeal) {
            System.out.printf("Abaixo do peso ideal. Peso ideal: %.2f kg%n", pesoIdeal);
        } else if (peso > pesoIdeal) {
            System.out.printf("Acima do peso ideal. Peso ideal: %.2f kg%n", pesoIdeal);
        } else {
            System.out.printf("No peso ideal. Peso ideal: %.2f kg%n", pesoIdeal);
        }
        
        s.close();
    }
}