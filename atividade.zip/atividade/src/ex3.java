import java.util.Scanner;

public class ex3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        System.out.print("Informe o valor total da compra: ");
        double valorTotal = s.nextDouble();
        
        System.out.print("Informe o codigo da condicao de pagamento (1-4): ");
        int codigoPagamento = s.nextInt();
        
        double valorFinal = valorTotal;
        int parcelas = 1;
        
        switch (codigoPagamento) {
            case 1:
                valorFinal = valorTotal * 0.90;
                parcelas = 1;
                break;
            case 2:
                valorFinal = valorTotal * 0.92;
                parcelas = 1;
                break;
            case 3:
                valorFinal = valorTotal;
                parcelas = 5;
                break;
            case 4:
                valorFinal = valorTotal * 1.05;
                parcelas = 10;
                break;
            default:
                System.out.println("Codigo invalido.");
                s.close();
                return;
        }
        
        double valorParcela = valorFinal / parcelas;
        System.out.printf("Valor total: R$%.2f, Parcelas: %d, Valor por parcela: R$%.2f%n", valorFinal, parcelas, valorParcela);
        
        s.close();
    }
}