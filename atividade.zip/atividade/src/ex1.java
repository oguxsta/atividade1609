import java.util.Scanner;
import java.time.LocalDate;

public class ex1 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Informe um numero de mes (1-12): ");
        int mes = s.nextInt();
        
        if (mes < 1 || mes > 12) {
            System.out.println("Valor Inválido");
        } else {
            String[] meses = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
                              "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
            int mesAtual = LocalDate.now().getMonthValue();
            String nomeMes = meses[mes - 1];
            
            if (mes < mesAtual) {
                System.out.println(nomeMes + " - Mes ja passou");
            } else if (mes == mesAtual) {
                System.out.println(nomeMes + " - Mes atual");
            } else {
                System.out.println(nomeMes + " - Mes futuro");
            }
        }
        s.close();
    }
}